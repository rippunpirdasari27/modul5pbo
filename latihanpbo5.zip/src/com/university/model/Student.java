
package com.university.model;

public class Student {
    private String studentId;
    private String name;
    protected int age;
    public double gpa;

    // Konstruktor
    public Student(String studentId, String name, int age, double gpa) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.gpa = gpa;
    }

    // Getter dan Setter
    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    // Method untuk menampilkan data mahasiswa
    public void displayInfo() {
        System.out.println("ID: " + studentId + ", Nama: " + name + ", Umur: " + age + ", GPA: " + gpa);
    }
}
